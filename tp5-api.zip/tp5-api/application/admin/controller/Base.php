<?php

namespace app\admin\controller;

use app\common\controller\Admin;

/**
 * 系统基类
 * @author hardphp@163.com
 *
 */
class Base extends Admin
{
    public function _initialize()
    {
        parent::_initialize();

    }


}
