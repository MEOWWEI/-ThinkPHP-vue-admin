<?php

namespace app\admin\controller;

use app\admin\controller\Base;

/**
 * 系统首页
 * @author hardphp@163.com
 */
class Index extends Base
{

    public function index()
    {
        return 11;
    }



}
