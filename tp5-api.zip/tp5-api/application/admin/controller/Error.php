<?php

namespace app\admin\controller;

use app\admin\controller\Base;
use \think\Request;

/**
 * 管理员管理
 * @author hardphp@163.com
 */
class Error extends Base
{
    /**
     * 列表
     */
    public function _empty()
    {
		return [];
        
    }

   

}
