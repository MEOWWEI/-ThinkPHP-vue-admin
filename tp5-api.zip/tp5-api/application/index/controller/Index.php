<?php

namespace app\index\controller;

class Index
{

    public function index()
    {
    echo 222;
		

    }
    public function hello(){
        echo 'hello';
    }


}
